<div class="col-md-10" style=" margin-left:20%; border-radius:2pt; padding:3pt; position:absolute; overflow:auto; max-width: 75%; max-height:75%;">


<h1>Result</h1><br><br>
  
<div class="container">
Referral number:<br><br>
Referral date:<br><br>
Exam date:<br><br>
Exam name:<br>
Total average:<br>
Rating:<br><br>

</div>



</div>
</div>
</div>
</div>
