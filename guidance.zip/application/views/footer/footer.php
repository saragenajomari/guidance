<footer class="container-fluid text-center" style="width: 100%; height: 80px; background: #2eb82e; text-align: center; color: white;">
				<p>
					Copyright ©2017. All Rights Reserved.<br />University of San Carlos <br /> P. del Rosario Street, Cebu City, Philippines 6000 <br />
					Phone: +63 (32) 253 1000 | Fax: +63 (32) 255 4341 | E-mail:ismis@usc.edu.ph
				</p>
</footer>

	</body>

</html>