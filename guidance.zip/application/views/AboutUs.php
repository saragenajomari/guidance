
<div class="col-md-10" style="margin-left:20%; border-radius:2pt; padding:3pt; position:absolute; overflow:hidden; max-width: 75%; max-height:75%;">

<div class="page-header">
  <h1>About Us<small></small></h1>
</div>
<p style="font-size: 15pt;">Testing Office - Talamban Campus<p>
<p>Louela A. Jacel <br />Ann S. Ares</p>
<p>Telephone Number: 230-0100 local 106</p><br /><br />
<p style="font-size: 15pt;">Testing Office - Downtown Campus<p>
<p>Remedios A. Baculao <br />Joan P. Sucalit</p>
<p>Telephone Number: 255-2433</p>
</div>

</div>
</div>
