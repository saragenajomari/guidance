<div class="col-md-10" style="margin-left:20%; border-radius:2pt; padding:3pt; position:absolute; overflow:auto; max-width: 75%; max-height:75%;">


<h1>General Report</h1><br><br>
  
<div class="col-sm-6">
					<div class="box">
						<div class="box-header">
							<h2><i class="fa fa-list-alt"></i><span class="break"></span>Pie</h2>
							<div class="box-icon">
								<a href="charts-flot.html#" class="btn-setting"><i class="fa fa-wrench"></i></a>
								<a href="charts-flot.html#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a>
								<a href="charts-flot.html#" class="btn-close"><i class="fa fa-times"></i></a>
							</div>
						</div>
						<div class="box-content">
								<div id="piechart" style="height: 300px; padding: 0px; position: relative;"><canvas class="flot-base" width="306" height="300" style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 306px; height: 300px;"></canvas><canvas class="flot-overlay" width="306" height="300" style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 306px; height: 300px;"></canvas><span class="pieLabel" id="pieLabel0" style="position: absolute; top: 6px; left: 125px;"><div style="font-size:x-small;text-align:center;padding:2px;color:rgb(250,88,51);">Internet Explorer<br>3%</div></span><span class="pieLabel" id="pieLabel1" style="position: absolute; top: 16px; left: 186.5px;"><div style="font-size:x-small;text-align:center;padding:2px;color:rgb(47,171,233);">Mobile<br>7%</div></span><span class="pieLabel" id="pieLabel2" style="position: absolute; top: 101px; left: 262.5px;"><div style="font-size:x-small;text-align:center;padding:2px;color:rgb(250,187,61);">Safari<br>22%</div></span><span class="pieLabel" id="pieLabel3" style="position: absolute; top: 238px; left: 213px;"><div style="font-size:x-small;text-align:center;padding:2px;color:rgb(120,205,81);">Opera<br>16%</div></span><span class="pieLabel" id="pieLabel4" style="position: absolute; top: 239px; left: 61.5px;"><div style="font-size:x-small;text-align:center;padding:2px;color:rgb(200,70,40);">Firefox<br>23%</div></span><span class="pieLabel" id="pieLabel5" style="position: absolute; top: 54px; left: 32.5px;"><div style="font-size:x-small;text-align:center;padding:2px;color:rgb(37,136,186);">Chrome<br>29%</div></span></div>
						</div>
					</div>
				</div>
</div>
</div>